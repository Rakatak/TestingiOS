======================================
Google Conversion Tracking SDK for iOS
======================================

This is the Google Conversion Tracking SDK for iOS.

Requirements:
- An AdWords account.
- Xcode 5.1 or later.
- Runtime of iOS 5.0 or later.

The latest documentation and code samples are available at:
https://developers.google.com/app-conversion-tracking/
